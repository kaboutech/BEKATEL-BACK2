import Vue from 'vue'
import App from './app-settings.vue'

new Vue({
  el: '#app-settings',
  components: {
    App
  }
})