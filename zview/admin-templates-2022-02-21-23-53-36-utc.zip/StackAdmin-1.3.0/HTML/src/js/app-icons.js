import Vue from 'vue'
import AppIconsApp from './components/AppIconsApp.vue'

new Vue({
  el: '#app-icons',
  components: {
    AppIconsApp
  }
})